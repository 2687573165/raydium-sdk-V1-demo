"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const web3_js_1 = require("@solana/web3.js");
// 创建与 Solana 网络的连接
const connection = new web3_js_1.Connection('https://solana-mainnet-archive.allthatnode.com/NsTVN0SB8i8SX4kwS4bVtnDOv5PnYmpj');
;
// 指定你想要获取的区块的编号
const blockNumber = 238341790;
// 获取区块信息
function getBlockInfo(blockNumber) {
    return __awaiter(this, void 0, void 0, function* () {
        const blockConfig = {
            maxSupportedTransactionVersion: 0
        };
        try {
            // const block = await connection.getBlock(blockNumber,blockConfig);
            // console.log('Block Info:', block?.transactions[0].transaction.message.compiledInstructions);
            const Txdata = yield connection.getTransaction('26XfpL6B5atx5RR6hqWTXjb5TxPNyFBVXzVqK5NU2GGWhhn4ztPwti4HLse7x6Y5DfTbEuYcmzdurAnitGeWbTq3', blockConfig);
        }
        catch (error) {
            console.error('Error fetching block:', error);
        }
    });
}
// 调用函数获取区块信息
getBlockInfo(blockNumber);
//# sourceMappingURL=token_test.js.map