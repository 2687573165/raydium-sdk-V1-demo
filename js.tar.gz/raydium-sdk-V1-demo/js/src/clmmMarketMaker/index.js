"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const web3_js_1 = require("@solana/web3.js");
const node_cron_1 = __importDefault(require("node-cron"));
const axios_1 = __importDefault(require("axios"));
const tokenAccount_1 = require("./tokenAccount");
const bs58_1 = __importDefault(require("bs58"));
const config_1 = require("../../config");
// all clmm pools: https://api.raydium.io/v2/ammV3/ammPools
// SOL-USDC pool id 2QdhepnKRTLjjSqPL1PtKNwqrUkoLee5Gqs8bvZhRdMv
const commitment = 'confirmed';
const poolId = process.argv[2];
const createDeviation = !isNaN(Number(process.argv[3])) ? Number(process.argv[3]) : 10;
const closeDeviation = !isNaN(Number(process.argv[4])) ? Number(process.argv[4]) : 5;
const connection = new web3_js_1.Connection('rpc node url', commitment);
const owner = web3_js_1.Keypair.fromSecretKey(bs58_1.default.decode(`your secret key here`));
let cachedPools = [];
let accounts = [];
let accountsRawInfo = [];
let accountListenerId;
function getPoolInfo(poolId) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!poolId)
            return {};
        if (!cachedPools.length) {
            const { data } = yield axios_1.default.get(config_1.ENDPOINT + config_1.RAYDIUM_MAINNET_API.clmmPools);
            cachedPools = data.data;
        }
        const { data } = yield axios_1.default.get(config_1.ENDPOINT + config_1.RAYDIUM_MAINNET_API.time);
        const pool = cachedPools.find((p) => p.id === poolId);
        if (pool) {
            return yield raydium_sdk_1.Clmm.fetchMultiplePoolInfos({
                poolKeys: [pool],
                connection,
                ownerInfo: { tokenAccounts: accountsRawInfo, wallet: owner.publicKey },
                chainTime: (Date.now() + (data.offset || 0 * 1000)) / 1000,
                batchRequest: true,
            });
        }
        return {};
    });
}
function checkPosition() {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        if (!poolId) {
            console.log('please provide pool id');
            return;
        }
        if (!accounts.length) {
            const fetchFuc = () => __awaiter(this, void 0, void 0, function* () {
                const accountRes = yield (0, tokenAccount_1.getUserTokenAccounts)({
                    connection,
                    commitment,
                    owner: owner.publicKey,
                });
                accounts = [...accountRes.accounts];
                accountsRawInfo = [...accountRes.accountsRawInfo];
            });
            yield fetchFuc();
            if (accountListenerId) {
                connection.removeAccountChangeListener(accountListenerId);
                accountListenerId = undefined;
            }
            accountListenerId = connection.onAccountChange(owner.publicKey, fetchFuc);
        }
        const res = yield getPoolInfo(poolId);
        const parsedPool = res[poolId];
        if (parsedPool) {
            console.log(`\nConcentrated pool: ${poolId}`);
            console.log(`\nclose deviation setting: ${closeDeviation}%, create deviation setting: ${createDeviation}%`);
            const currentPrice = parsedPool.state.currentPrice;
            (_a = parsedPool.positionAccount) === null || _a === void 0 ? void 0 : _a.forEach((position, idx) => __awaiter(this, void 0, void 0, function* () {
                const { priceLower, priceUpper } = position;
                console.log(`\n===== position ${idx + 1} =====\n`, `current price: ${currentPrice}\n`, `priceLower: ${priceLower.toString()}\n`, `priceUpper: ${priceUpper.toString()}`);
                const currentPositionMid = priceLower.add(priceUpper).div(2);
                const [closeLow, closeUp] = [
                    currentPrice.mul((100 - closeDeviation) / 100),
                    currentPrice.mul((100 + closeDeviation) / 100),
                ];
                if (currentPositionMid < closeLow || currentPositionMid > closeUp) {
                    console.log('\n⛔ close position triggered!');
                    console.log(`closeLower:${closeLow}\ncurrentPosition:${currentPositionMid}\ncloseUpper: ${closeUp}`);
                    /* close position here */
                    // await closePositionTx({
                    //   connection,
                    //   poolInfo: parsedPool.state,
                    //   position,
                    //   owner,
                    //   tokenAccounts: accountsRawInfo,
                    // });
                    const [recreateLower, recreateUpper] = [
                        currentPrice.mul((100 - createDeviation) / 100),
                        currentPrice.mul((100 + createDeviation) / 100),
                    ];
                    console.log('\n ✅ create new position');
                    console.log(`priceLower:${recreateLower}\npriceUpper: ${recreateUpper}`);
                    /* create position here */
                    // await createPositionTx({
                    //   connection,
                    //   poolInfo: parsedPool.state,
                    //   priceLower,
                    //   priceUpper,
                    //   owner,
                    //   tokenAccounts: accountsRawInfo,
                    //   amountA: new BN(10000),
                    // });
                    return;
                }
                console.log('position in range, no action needed');
            }));
        }
    });
}
const job = node_cron_1.default.schedule('*/1 * * * *', checkPosition, {
    scheduled: false,
});
if (poolId) {
    checkPosition();
    job.start();
}
else {
    console.log('please provide pool id');
}
//# sourceMappingURL=index.js.map