"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.closePositionTx = exports.createPositionTx = void 0;
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const bn_js_1 = __importDefault(require("bn.js"));
const util_1 = require("./util");
function createPositionTx({ connection, poolInfo, priceLower, priceUpper, owner, tokenAccounts, makeTxVersion = raydium_sdk_1.TxVersion.V0, amountA, }) {
    return __awaiter(this, void 0, void 0, function* () {
        const { tick: tickLower } = raydium_sdk_1.Clmm.getPriceAndTick({
            poolInfo,
            baseIn: true,
            price: priceLower, // will add position start price
        });
        const { tick: tickUpper } = raydium_sdk_1.Clmm.getPriceAndTick({
            poolInfo,
            baseIn: true,
            price: priceUpper, // will add position end price
        });
        const { liquidity, amountSlippageA, amountSlippageB } = raydium_sdk_1.Clmm.getLiquidityAmountOutFromAmountIn({
            poolInfo,
            slippage: 0,
            inputA: true,
            tickUpper,
            tickLower,
            amount: amountA, // e.g. new BN(100000),
            add: true, // SDK flag for math round direction
            amountHasFee: true,
            token2022Infos: yield (0, raydium_sdk_1.fetchMultipleMintInfos)({
                connection,
                mints: [poolInfo.mintA.mint, poolInfo.mintB.mint],
            }),
            epochInfo: yield connection.getEpochInfo(),
        });
        const makeOpenPositionInstruction = yield raydium_sdk_1.Clmm.makeOpenPositionFromLiquidityInstructionSimple({
            connection,
            poolInfo,
            ownerInfo: {
                feePayer: owner.publicKey,
                wallet: owner.publicKey,
                tokenAccounts,
            },
            tickLower,
            tickUpper,
            liquidity,
            makeTxVersion,
            amountMaxA: amountSlippageA.amount,
            amountMaxB: amountSlippageB.amount,
        });
        return {
            txids: yield (0, util_1.buildAndSendTx)({
                connection,
                makeTxVersion,
                owner,
                innerSimpleV0Transaction: makeOpenPositionInstruction.innerTransactions,
            }),
        };
    });
}
exports.createPositionTx = createPositionTx;
function closePositionTx({ connection, poolInfo, position, owner, tokenAccounts, makeTxVersion = raydium_sdk_1.TxVersion.V0, }) {
    return __awaiter(this, void 0, void 0, function* () {
        const makeDecreaseLiquidityInstruction = yield raydium_sdk_1.Clmm.makeDecreaseLiquidityInstructionSimple({
            connection,
            poolInfo,
            ownerPosition: position,
            ownerInfo: {
                feePayer: owner.publicKey,
                wallet: owner.publicKey,
                tokenAccounts: tokenAccounts,
                closePosition: true, // for close
            },
            liquidity: position.liquidity, //for close position, use 'ammV3Position.liquidity' without dividend
            // slippage: 1, // if encouter slippage check error, try uncomment this line and set a number manually
            makeTxVersion,
            amountMinA: new bn_js_1.default(0),
            amountMinB: new bn_js_1.default(0),
        });
        return {
            txids: yield (0, util_1.buildAndSendTx)({
                connection,
                makeTxVersion,
                owner,
                innerSimpleV0Transaction: makeDecreaseLiquidityInstruction.innerTransactions,
            }),
        };
    });
}
exports.closePositionTx = closePositionTx;
//# sourceMappingURL=clmmTx.js.map