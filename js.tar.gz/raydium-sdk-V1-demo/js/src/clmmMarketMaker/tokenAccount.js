"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserTokenAccounts = void 0;
const spl_token_1 = require("@solana/spl-token");
const bn_js_1 = __importDefault(require("bn.js"));
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
function getUserTokenAccounts(props) {
    return __awaiter(this, void 0, void 0, function* () {
        const { connection, owner, commitment } = props;
        console.log("fetching token accounts...\n");
        const accounts = [];
        const accountsRawInfo = [];
        const solReq = connection.getAccountInfo(owner, commitment);
        const tokenReq = connection.getTokenAccountsByOwner(owner, { programId: spl_token_1.TOKEN_PROGRAM_ID }, commitment);
        const token2022Req = connection.getTokenAccountsByOwner(owner, { programId: spl_token_1.TOKEN_2022_PROGRAM_ID }, commitment);
        const [solRes, tokenRes, token2022Res] = yield Promise.all([
            solReq,
            tokenReq,
            token2022Req,
        ]);
        console.log("fetching token accounts done.\n");
        for (const { pubkey, account } of [
            ...tokenRes.value,
            ...token2022Res.value,
        ]) {
            const rawResult = raydium_sdk_1.SPL_ACCOUNT_LAYOUT.decode(account.data);
            const { mint, amount } = rawResult;
            const associatedTokenAddress = raydium_sdk_1.Spl.getAssociatedTokenAccount({
                mint,
                owner,
                programId: account.owner,
            });
            accounts.push({
                publicKey: pubkey,
                mint,
                isAssociated: associatedTokenAddress.equals(pubkey),
                amount,
                isNative: false,
            });
            accountsRawInfo.push({
                pubkey,
                accountInfo: rawResult,
                programId: account.owner,
            });
        }
        accounts.push({
            amount: new bn_js_1.default(solRes ? String(solRes.lamports) : 0),
            isNative: true,
        });
        return { accounts, accountsRawInfo };
    });
}
exports.getUserTokenAccounts = getUserTokenAccounts;
//# sourceMappingURL=tokenAccount.js.map