"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildAndSendTx = exports.sendTx = exports.getComputeBudgetConfig = void 0;
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const axios_1 = __importDefault(require("axios"));
const web3_js_1 = require("@solana/web3.js");
const config_1 = require("../../config");
function getComputeBudgetConfig() {
    var _a;
    return __awaiter(this, void 0, void 0, function* () {
        const { data } = yield axios_1.default.get(`https://solanacompass.com/api/fees?cacheFreshTime=${5 * 60 * 1000}`);
        const { avg } = (_a = data === null || data === void 0 ? void 0 : data[15]) !== null && _a !== void 0 ? _a : {};
        if (!avg)
            return undefined; // fetch error
        return {
            units: 400000,
            microLamports: Math.min(Math.ceil((avg * 1000000) / 400000), 25000),
        };
    });
}
exports.getComputeBudgetConfig = getComputeBudgetConfig;
function sendTx(connection, payer, txs, options) {
    return __awaiter(this, void 0, void 0, function* () {
        const txids = [];
        for (const iTx of txs) {
            if (iTx instanceof web3_js_1.VersionedTransaction) {
                iTx.sign([payer]);
                txids.push(yield connection.sendTransaction(iTx, options));
            }
            else {
                txids.push(yield connection.sendTransaction(iTx, [payer], options));
            }
        }
        return txids;
    });
}
exports.sendTx = sendTx;
function buildAndSendTx({ connection, makeTxVersion, owner, innerSimpleV0Transaction, }) {
    return __awaiter(this, void 0, void 0, function* () {
        const willSendTx = yield (0, raydium_sdk_1.buildSimpleTransaction)({
            connection,
            makeTxVersion,
            payer: owner.publicKey,
            innerTransactions: innerSimpleV0Transaction,
            addLookupTableInfo: config_1.addLookupTableInfo,
        });
        return yield sendTx(connection, owner, willSendTx);
    });
}
exports.buildAndSendTx = buildAndSendTx;
//# sourceMappingURL=util.js.map