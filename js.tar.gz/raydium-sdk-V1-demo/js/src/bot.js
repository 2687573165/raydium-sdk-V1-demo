"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const bs58_1 = __importDefault(require("bs58"));
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const config_1 = require("../config");
const web3_js_1 = require("@solana/web3.js");
const anchor_1 = require("@coral-xyz/anchor");
const common_sdk_1 = require("@orca-so/common-sdk");
const whirlpools_sdk_1 = require("@orca-so/whirlpools-sdk");
const decimal_js_1 = __importDefault(require("decimal.js"));
const TOKEN_PROGRAM_ID = new web3_js_1.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA');
const connection = new web3_js_1.Connection("https://rpc.ankr.com/solana/8eeea1727223c7cfa93a7ec0f4bdeac5e009b47a365e89b759c852fec72d4180", 'confirmed');
let TokenMap = new Map();
TokenMap.set("So11111111111111111111111111111111111111112", true);
TokenMap.set("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v", true);
function Swap(pool) {
    return __awaiter(this, void 0, void 0, function* () {
        // Create WhirlpoolClient
        const provider = anchor_1.AnchorProvider.env();
        const ORCA_WHIRLPOOL_PROGRAM_ID = new web3_js_1.PublicKey("whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc");
        const ctx = whirlpools_sdk_1.WhirlpoolContext.withProvider(provider, ORCA_WHIRLPOOL_PROGRAM_ID);
        const client = (0, whirlpools_sdk_1.buildWhirlpoolClient)(ctx);
        console.log("endpoint:", ctx.connection.rpcEndpoint);
        console.log("wallet pubkey:", ctx.wallet.publicKey.toBase58());
        const fromToken = { mint: new web3_js_1.PublicKey("BgNSCjWzeruX7wcDxedh5Q8Z9dw8CRLJJvyZwtD2XHji"), decimals: 9 };
        const toToken = { mint: new web3_js_1.PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"), decimals: 6 };
        const whirlpool_pubkey = new web3_js_1.PublicKey(pool);
        const whirlpool = yield client.getPool(whirlpool_pubkey);
        const amount_in = new decimal_js_1.default("50" /* devUSDC */);
        // // Obtain swap estimation (run simulation)
        const quote = yield (0, whirlpools_sdk_1.swapQuoteByInputToken)(whirlpool, 
        // Input token and amount
        fromToken.mint, common_sdk_1.DecimalUtil.toBN(amount_in, fromToken.decimals), 
        // Acceptable slippage (10/1000 = 1%)
        common_sdk_1.Percentage.fromFraction(10, 1000), ctx.program.programId, ctx.fetcher, whirlpools_sdk_1.IGNORE_CACHE);
        // // Output the estimation
        console.log("estimatedAmountIn:", common_sdk_1.DecimalUtil.fromBN(quote.estimatedAmountIn, fromToken.decimals).toString(), "fromToken");
        console.log("estimatedAmountOut:", common_sdk_1.DecimalUtil.fromBN(quote.estimatedAmountOut, toToken.decimals).toString(), "toToken");
        console.log("otherAmountThreshold:", common_sdk_1.DecimalUtil.fromBN(quote.otherAmountThreshold, toToken.decimals).toString(), "toToken");
        // // Send the transaction
        const tx = yield whirlpool.swap(quote);
        // tx.build
        const signature = yield tx.buildAndExecute();
        console.log("signature:", signature);
        // // Wait for the transaction to complete
        // const latest_blockhash = await ctx.connection.getLatestBlockhash();
        // await ctx.connection.confirmTransaction({signature, ...latest_blockhash}, "confirmed");
    });
}
function Block_Logs() {
    return __awaiter(this, void 0, void 0, function* () {
        const Logsconnection = new web3_js_1.Connection("https://rpc.ankr.com/solana/ws/8eeea1727223c7cfa93a7ec0f4bdeac5e009b47a365e89b759c852fec72d4180", 'confirmed');
        const programIds = [
            new web3_js_1.PublicKey('whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc'), // orca
            new web3_js_1.PublicKey('675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8'), // Raydium
            // 添加更多程序ID...
        ];
        const subscriptionIds = programIds.map(programId => Logsconnection.onLogs(programId, (logs, context) => __awaiter(this, void 0, void 0, function* () {
            for (let index = 0; index < logs.logs.length; index++) {
                const element = logs.logs[index];
                // console.log(element)
                //raydium
                if (programId.toBase58() == "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8") {
                    if (element.includes("initialize2: InitializeInstruction2")) {
                        // console.log(`New logs for program ${programId.toBase58()}:`);
                        // console.log('Block:', context.slot);
                        // console.log('Logs:', logs.logs);
                        console.log('Raydium  signature:', logs.signature);
                        let data = yield GetTransaction(logs.signature);
                    }
                }
                // orca
                if (programId.toBase58() == "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc") {
                    if (element == "Program log: Instruction: InitializePool") {
                        // console.log(`New logs for program ${programId.toBase58()}:`);
                        // console.log('Block:', context.slot);
                        // console.log('Logs:', logs.logs);
                        console.log('orca signature:', logs.signature);
                        let data = yield GetTransaction(logs.signature);
                    }
                }
            }
        })));
    });
}
function GetTransaction(tx) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log(tx);
        // InitializePool
        connection.getTransaction(tx, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 })
            .then(transactionInfo => {
            var _a, _b, _c;
            // console.log(transactionInfo.transaction.message);
            if (transactionInfo != null) {
                if ('instructions' in transactionInfo.transaction.message) {
                    const getAccountKeys = transactionInfo.transaction.message.getAccountKeys();
                    let accounts = transactionInfo.transaction.message.instructions;
                    for (let index = 0; index < accounts.length; index++) {
                        const element = accounts[index];
                        if (element.accounts.length == 11) {
                            console.log((_a = getAccountKeys.get(element.accounts[1])) === null || _a === void 0 ? void 0 : _a.toBase58());
                            console.log((_b = getAccountKeys.get(element.accounts[2])) === null || _b === void 0 ? void 0 : _b.toBase58());
                            console.log((_c = getAccountKeys.get(element.accounts[4])) === null || _c === void 0 ? void 0 : _c.toBase58());
                        }
                    }
                    // Swap(getAccountKeys.get(accounts[0]).toBase58())
                }
                else {
                    let staticAccountKeys = transactionInfo.transaction.message.staticAccountKeys;
                    let Instructions = transactionInfo.transaction.message.compiledInstructions;
                    for (let index = 0; index < Instructions.length; index++) {
                        const element = Instructions[index];
                        if (element.accountKeyIndexes.length == 21) {
                            let pool = staticAccountKeys[element.accountKeyIndexes[4]].toBase58();
                            let tokenA = staticAccountKeys[element.accountKeyIndexes[8]].toBase58();
                            let tokenB = staticAccountKeys[element.accountKeyIndexes[9]].toBase58();
                            raydiumSwap(pool);
                            // if(TokenMap.get(tokenA)){
                            // }else if(TokenMap.get(tokenB)){
                            // }
                        }
                    }
                }
            }
            // console.log(transactionInfo.transaction.message.compiledInstructions)
            // console.log(transactionInfo.transaction.message.addressTableLookups)
        })
            .catch(err => {
            console.error(err);
        });
    });
}
// Raydium_Swap
function getTokenAccountsByOwner(connection, owner) {
    return __awaiter(this, void 0, void 0, function* () {
        const tokenResp = yield connection.getTokenAccountsByOwner(owner, {
            programId: TOKEN_PROGRAM_ID
        });
        const accounts = [];
        for (const { pubkey, account, } of tokenResp.value) {
            accounts.push({
                programId: TOKEN_PROGRAM_ID,
                pubkey,
                accountInfo: raydium_sdk_1.SPL_ACCOUNT_LAYOUT.decode(account.data)
            });
        }
        return accounts;
    });
}
function get_token_amount(poolId, buying) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const rpc_url = "https://api.mainnet-beta.solana.com";
            const version = 4;
            const connection = new web3_js_1.Connection(rpc_url);
            const account = yield connection.getAccountInfo(new web3_js_1.PublicKey(poolId));
            const { state: LiquidityStateLayout } = raydium_sdk_1.Liquidity.getLayouts(version);
            //@ts-ignore
            const fields = LiquidityStateLayout.decode(account === null || account === void 0 ? void 0 : account.data);
            const { status, baseMint, quoteMint, lpMint, openOrders, targetOrders, baseVault, quoteVault, marketId, baseDecimal, quoteDecimal, } = fields;
            var is_valid = false;
            [quoteMint, baseMint, lpMint].forEach((e) => {
                if (e.toBase58() != '11111111111111111111111111111111') {
                    is_valid = true;
                }
            });
            if (!is_valid) {
                return -1;
            }
            //fetching token data
            const secretkey = bs58_1.default.decode("hDwP6axbYSQEvSwA7V7t1LP5QJEDAq6LVffXHEaGTWNZhz7uzXqeN7pvj5RSDwnPLmhrUzg1rPeSPbnPXzuqyQb");
            const ownerKeypair = web3_js_1.Keypair.fromSecretKey(secretkey);
            const owner_address = ownerKeypair.publicKey;
            const tokenAddress = buying ? quoteMint : baseMint;
            //console.log(tokenAddress.toBase58());
            const bal = yield connection.getBalance(new web3_js_1.PublicKey(owner_address.toBase58()));
            if (bal < 0.01) {
                return -2;
            }
            if (tokenAddress.toBase58() == 'So11111111111111111111111111111111111111112') {
                return (bal / 1000000000) - 0.0099;
            }
            else {
                const tokenAccounts = yield connection.getParsedTokenAccountsByOwner(owner_address, { programId: new web3_js_1.PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA') });
                for (var cand in tokenAccounts.value) {
                    if (tokenAccounts.value[cand].account.data.parsed.info.mint === tokenAddress.toBase58()) {
                        const tokenAccount = tokenAccounts.value[cand];
                        const tokenBalance = tokenAccount.account.data.parsed.info.tokenAmount.uiAmount;
                        return tokenBalance;
                    }
                }
                return 0;
            }
        }
        catch (e) {
            console.log(e);
            return -1;
        }
    });
}
function fetchPoolKeys(connection, poolId, version = 4) {
    return __awaiter(this, void 0, void 0, function* () {
        const serumVersion = 10;
        const marketVersion = 3;
        const programId = new web3_js_1.PublicKey('675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8');
        const serumProgramId = new web3_js_1.PublicKey('srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX');
        const account = yield connection.getAccountInfo(poolId);
        const { state: LiquidityStateLayout } = raydium_sdk_1.Liquidity.getLayouts(version);
        //@ts-ignore
        const fields = LiquidityStateLayout.decode(account === null || account === void 0 ? void 0 : account.data);
        const { status, baseMint, quoteMint, lpMint, openOrders, targetOrders, baseVault, quoteVault, marketId, baseDecimal, quoteDecimal, } = fields;
        let withdrawQueue, lpVault;
        if (raydium_sdk_1.Liquidity.isV4(fields)) {
            withdrawQueue = fields.withdrawQueue;
            lpVault = fields.lpVault;
        }
        else {
            withdrawQueue = web3_js_1.PublicKey.default;
            lpVault = web3_js_1.PublicKey.default;
        }
        // uninitialized
        // if (status.isZero()) {
        //   return ;
        // }
        const associatedPoolKeys = raydium_sdk_1.Liquidity.getAssociatedPoolKeys({
            version: version,
            marketVersion,
            marketId,
            baseMint: baseMint,
            quoteMint: quoteMint,
            baseDecimals: baseDecimal.toNumber(),
            quoteDecimals: quoteDecimal.toNumber(),
            programId,
            marketProgramId: serumProgramId,
        });
        const poolKeys = {
            id: poolId,
            baseMint,
            quoteMint,
            lpMint,
            version,
            programId,
            authority: associatedPoolKeys.authority,
            openOrders,
            targetOrders,
            baseVault,
            quoteVault,
            withdrawQueue,
            lpVault,
            marketVersion: serumVersion,
            marketProgramId: serumProgramId,
            marketId,
            marketAuthority: associatedPoolKeys.marketAuthority,
        };
        const marketInfo = yield connection.getAccountInfo(marketId);
        const { state: MARKET_STATE_LAYOUT } = raydium_sdk_1.Market.getLayouts(marketVersion);
        //@ts-ignore
        const market = MARKET_STATE_LAYOUT.decode(marketInfo.data);
        const { baseVault: marketBaseVault, quoteVault: marketQuoteVault, bids: marketBids, asks: marketAsks, eventQueue: marketEventQueue, } = market;
        // const poolKeys: LiquidityPoolKeys;
        return Object.assign(Object.assign({}, poolKeys), {
            marketBaseVault,
            marketQuoteVault,
            marketBids,
            marketAsks,
            marketEventQueue,
        });
    });
}
function compute(connection, poolKeys, curr_in, curr_out, amount_in, slip) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const poolInfo = yield raydium_sdk_1.Liquidity.fetchInfo({ connection, poolKeys });
            console.log("开放时间:", poolInfo.startTime.toString());
            //setting up decimals
            var in_decimal;
            var out_decimal;
            if (curr_in.toBase58() === poolKeys.baseMint.toBase58()) {
                in_decimal = poolInfo.baseDecimals;
                out_decimal = poolInfo.quoteDecimals;
            }
            else {
                out_decimal = poolInfo.baseDecimals;
                in_decimal = poolInfo.quoteDecimals;
            }
            //priming and computing
            const amountIn = new raydium_sdk_1.TokenAmount(new raydium_sdk_1.Token(TOKEN_PROGRAM_ID, curr_in, in_decimal), amount_in, false);
            const currencyOut = new raydium_sdk_1.Token(TOKEN_PROGRAM_ID, curr_out, out_decimal);
            const slippage = new raydium_sdk_1.Percent(slip, 100);
            const { amountOut, minAmountOut, currentPrice, executionPrice, priceImpact, fee, } = raydium_sdk_1.Liquidity.computeAmountOut({ poolKeys, poolInfo, amountIn, currencyOut, slippage });
            return [
                amountOut,
                minAmountOut,
                currentPrice,
                executionPrice,
                priceImpact,
                fee,
                amountIn,
            ];
        }
        catch (e) {
            console.log(e);
            return 1;
        }
    });
}
function raydiumSwap(pool) {
    return __awaiter(this, void 0, void 0, function* () {
        const secretkey = bs58_1.default.decode("hDwP6axbYSQEvSwA7V7t1LP5QJEDAq6LVffXHEaGTWNZhz7uzXqeN7pvj5RSDwnPLmhrUzg1rPeSPbnPXzuqyQb");
        const ownerKeypair = web3_js_1.Keypair.fromSecretKey(secretkey);
        // const token_amount= await get_token_amount("HNeta6oxYy6DHT5gwEBFbxNeAj7U3wutUWzZtcjc2W17",true);
        // console.log(token_amount)
        const version = 4;
        const pool_keys = yield fetchPoolKeys(connection, new web3_js_1.PublicKey(pool), 4);
        const poolKeys = pool_keys;
        // console.log( pool_keys)
        var token_in_key;
        var token_out_key;
        if (TokenMap.get(pool_keys.quoteMint.toBase58())) {
            token_in_key = pool_keys.quoteMint;
            token_out_key = pool_keys.baseMint;
        }
        else {
            token_in_key = pool_keys.baseMint;
            token_out_key = pool_keys.quoteMint;
        }
        // console.log(token_in_key)
        // console.log(token_out_key)
        const computation = yield compute(connection, pool_keys, token_in_key, token_out_key, 0.00001, 100);
        const amountOut = computation[0];
        const minAmountOut = computation[1];
        const currentPrice = computation[2];
        const executionPrice = computation[3];
        const priceImpact = computation[4];
        const fee = computation[5];
        const amountIn = computation[6];
        console.log(`\n\tAmount out: ${amountOut.toFixed()},\n\tMin Amount out: ${minAmountOut.toFixed()}`);
        const token_accounts = yield getTokenAccountsByOwner(connection, ownerKeypair.publicKey);
        // -------- step 2: create instructions by SDK function --------
        const inst = yield raydium_sdk_1.Liquidity.makeSwapInstructionSimple({
            connection,
            poolKeys,
            userKeys: {
                tokenAccounts: token_accounts,
                owner: ownerKeypair.publicKey,
            },
            amountIn: amountIn,
            amountOut: minAmountOut,
            fixedSide: 'in',
            makeTxVersion: config_1.makeTxVersion,
        });
        const tx = new web3_js_1.Transaction();
        const signers = [ownerKeypair];
        inst.innerTransactions[0].instructions.forEach(e => {
            tx.add(e);
        });
        inst.innerTransactions[0].signers.forEach(e => {
            signers.push(e);
        });
        // 获取当前时间的时间戳（毫秒）
        const timestampInMilliseconds = Date.now();
        // 将毫秒时间戳转换为秒
        const timestampInSeconds = Math.floor(timestampInMilliseconds / 1000);
        // 打印时间戳
        console.log(timestampInSeconds);
        // const txids =  await buildAndSendTx(inst.innerTransactions) 
        sendTx(connection, tx, signers);
        // console.log(txids)
    });
}
function sendTx(connection, transaction, signers) {
    return __awaiter(this, void 0, void 0, function* () {
        const hash_info = (yield connection.getLatestBlockhashAndContext()).value;
        transaction.recentBlockhash = hash_info.blockhash;
        transaction.lastValidBlockHeight = hash_info.lastValidBlockHeight;
        transaction.feePayer = signers[0].publicKey;
        transaction.sign(...signers);
        const rawTransaction = transaction.serialize();
        var txid;
        try {
            txid = yield connection.sendRawTransaction(rawTransaction, { skipPreflight: true, });
            console.log(txid);
        }
        catch (e) {
            console.log(e);
            return 1;
        }
        // while (true){
        //   const ret = await connection.getSignatureStatus(txid, {searchTransactionHistory:true})
        //   try {
        //     //@ts-ignore
        //     if (ret){
        //       if (ret.value && ret.value.err == null){
        //         return 0
        //       } else if (ret.value && ret.value.err != null){
        //         return 1
        //       }else{
        //         continue
        //       }
        //     }
        //   } catch(e){
        //     return 1
        //   }
        // }
    });
}
Block_Logs().catch(err => {
    console.error(err);
});
// raydiumSwap("DNdf5pgTVewhHfmqwkp8cT3aGmZdgXSyNu6EwG7cac8g")
//# sourceMappingURL=bot.js.map