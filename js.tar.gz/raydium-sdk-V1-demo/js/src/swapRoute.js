"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const spl_token_1 = require("@solana/spl-token");
const web3_js_1 = require("@solana/web3.js");
const config_1 = require("../config");
const util_1 = require("./util");
/**
 * pre-action: fetch Clmm pools info and ammV2 pools info
 * step 1: get all route
 * step 2: fetch tick array and pool info
 * step 3: calculation result of all route
 * step 4: create instructions by SDK function
 * step 5: compose instructions to several transactions
 * step 6: send transactions
 */
function routeSwap(input) {
    return __awaiter(this, void 0, void 0, function* () {
        // -------- pre-action: fetch Clmm pools info and ammV2 pools info --------
        const clmmPools = [{ "id": "HNeta6oxYy6DHT5gwEBFbxNeAj7U3wutUWzZtcjc2W17",
                "mintProgramIdA": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
                "mintProgramIdB": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
                "mintA": "So11111111111111111111111111111111111111112",
                "mintB": "BgNSCjWzeruX7wcDxedh5Q8Z9dw8CRLJJvyZwtD2XHji",
                "vaultA": "AYUtAjiHPV8nKN2SWNfhCGFAHnPELncMgZV4GbD1T5W9",
                "vaultB": "BoUeV5ZWwtvn4nCJ3fLX171DMA5twbb1UBnczRnMqYxt",
                "mintDecimalsA": 9,
                "mintDecimalsB": 9,
                "ammConfig": { "id": "E64NGkDLLCdQ2yFNPcavaKptrEgmiQaNykUuLC1Qgwyp",
                    "index": 1,
                    "protocolFeeRate": 0,
                    "tradeFeeRate": 0,
                    "tickSpacing": 60,
                    "fundFeeRate": 0,
                    "fundOwner": "FundHfY8oo8J9KYGyfXFFuQCHe7Z1VBNmsj84eMcdYs4",
                    "description": "Best for most pairs" },
                "rewardInfos": [],
                "tvl": 0,
                "day": { "volume": 0, "volumeFee": 0, "feeA": 0, "feeB": 0, "feeApr": 0, "rewardApr": { "A": 0, "B": 0, "C": 0 }, "apr": 0, "priceMin": 0, "priceMax": 0 },
                "week": { "volume": 0, "volumeFee": 0, "feeA": 0, "feeB": 0, "feeApr": 0, "rewardApr": { "A": 0, "B": 0, "C": 0 }, "apr": 0, "priceMin": 0, "priceMax": 0 },
                "month": { "volume": 0, "volumeFee": 0, "feeA": 0, "feeB": 0, "feeApr": 0, "rewardApr": { "A": 0, "B": 0, "C": 0 }, "apr": 0, "priceMin": 0, "priceMax": 0 },
                "lookupTableAccount": "BWiG4jvKLJrhka8UF4fNqRgLUfVZhkHaqA4aAdAAVV5B" }]; // If the clmm pool is not required for routing, then this variable can be configured as undefined
        const clmmList = Object.values(yield raydium_sdk_1.Clmm.fetchMultiplePoolInfos({ connection: config_1.connection, poolKeys: clmmPools, chainTime: new Date().getTime() / 1000 })).map((i) => i.state);
        console.log(clmmList);
        // const sPool: ApiPoolInfo = await (await fetch(ENDPOINT + RAYDIUM_MAINNET_API.poolInfo)).json() // If the Liquidity pool is not required for routing, then this variable can be configured as undefined
        // -------- step 1: get all route --------
        const getRoute = raydium_sdk_1.TradeV2.getAllRoute({
            inputMint: input.inputToken instanceof raydium_sdk_1.Token ? input.inputToken.mint : web3_js_1.PublicKey.default,
            outputMint: input.outputToken instanceof raydium_sdk_1.Token ? input.outputToken.mint : web3_js_1.PublicKey.default,
            // apiPoolList: sPool,
            clmmList,
        });
        // -------- step 2: fetch tick array and pool info --------
        const [tickCache, poolInfosCache] = yield Promise.all([
            yield raydium_sdk_1.Clmm.fetchMultiplePoolTickArrays({ connection: config_1.connection, poolKeys: getRoute.needTickArray, batchRequest: true }),
            yield raydium_sdk_1.TradeV2.fetchMultipleInfo({ connection: config_1.connection, pools: getRoute.needSimulate, batchRequest: true }),
        ]);
        // console.log(tickCache)
        // -------- step 3: calculation result of all route --------
        const [routeInfo] = raydium_sdk_1.TradeV2.getAllRouteComputeAmountOut({
            directPath: getRoute.directPath,
            routePathDict: getRoute.routePathDict,
            simulateCache: poolInfosCache,
            tickCache,
            inputTokenAmount: input.inputTokenAmount,
            outputToken: input.outputToken,
            slippage: input.slippage,
            chainTime: new Date().getTime() / 1000, // this chain time
            feeConfig: input.feeConfig,
            mintInfos: yield (0, raydium_sdk_1.fetchMultipleMintInfos)({ connection: config_1.connection, mints: [
                    ...clmmPools.map(i => [{ mint: i.mintA, program: i.mintProgramIdA }, { mint: i.mintB, program: i.mintProgramIdB }]).flat().filter(i => i.program === spl_token_1.TOKEN_2022_PROGRAM_ID.toString()).map(i => new web3_js_1.PublicKey(i.mint)),
                ] }),
            epochInfo: yield config_1.connection.getEpochInfo(),
        });
        // console.log(routeInfo)
        // -------- step 4: create instructions by SDK function --------
        const { innerTransactions } = yield raydium_sdk_1.TradeV2.makeSwapInstructionSimple({
            routeProgram: config_1.PROGRAMIDS.Router,
            connection: config_1.connection,
            swapInfo: routeInfo,
            ownerInfo: {
                wallet: input.wallet.publicKey,
                tokenAccounts: input.walletTokenAccounts,
                associatedOnly: true,
                checkCreateATAOwner: true,
            },
            computeBudgetConfig: {
                units: 400000, // compute instruction
                microLamports: 1, // fee add 1 * 400000 / 10 ** 9 SOL
            },
            makeTxVersion: config_1.makeTxVersion,
        });
        console.log(innerTransactions[0].instructions);
        return { txids: yield (0, util_1.buildAndSendTx)(innerTransactions) };
    });
}
function howToUse() {
    return __awaiter(this, void 0, void 0, function* () {
        // sol -> new Currency(9, 'SOL', 'SOL')
        const outputToken = config_1.DEFAULT_TOKEN.gptx; // USDC
        // const inputToken = DEFAULT_TOKEN.WSOL // RAY
        const inputToken = new raydium_sdk_1.Currency(9, 'SOL', 'SOL');
        const inputTokenAmount = new (inputToken instanceof raydium_sdk_1.Token ? raydium_sdk_1.TokenAmount : raydium_sdk_1.CurrencyAmount)(inputToken, 100);
        // console.log(inputTokenAmount)
        const slippage = new raydium_sdk_1.Percent(1, 100);
        const walletTokenAccounts = yield (0, util_1.getWalletTokenAccount)(config_1.connection, config_1.wallet.publicKey);
        // console.log(wallet.publicKey.toBase58())
        routeSwap({
            inputToken,
            outputToken,
            inputTokenAmount,
            slippage,
            walletTokenAccounts,
            wallet: config_1.wallet,
            // feeConfig: {
            //   feeBps: new BN(25),
            //   feeAccount: Keypair.generate().publicKey // test
            // }
        }).then(({ txids }) => {
            /** continue with txids */
            console.log('txids', txids);
        });
    });
}
howToUse();
//# sourceMappingURL=swapRoute.js.map