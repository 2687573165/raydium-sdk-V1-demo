"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const assert_1 = __importDefault(require("assert"));
const raydium_sdk_1 = require("@raydium-io/raydium-sdk");
const config_1 = require("../config");
const util_1 = require("./util");
/**
 * pre-action: fetch basic AmmV2 info
 * step 1: create instructions by SDK function
 * step 2: compose instructions to several transactions
 * step 3: send transactions
 */
function ammRemoveLiquidity(input) {
    return __awaiter(this, void 0, void 0, function* () {
        // -------- pre-action: fetch basic info --------
        const ammV2PoolData = yield fetch(raydium_sdk_1.ENDPOINT + config_1.RAYDIUM_MAINNET_API.poolInfo).then((res) => res.json());
        (0, assert_1.default)(ammV2PoolData, 'fetch failed');
        const targetPoolInfo = [...ammV2PoolData.official, ...ammV2PoolData.unOfficial].find((poolInfo) => poolInfo.id === input.targetPool);
        (0, assert_1.default)(targetPoolInfo, 'cannot find the target pool');
        // -------- step 1: make instructions --------
        const poolKeys = (0, raydium_sdk_1.jsonInfo2PoolKeys)(targetPoolInfo);
        const removeLiquidityInstructionResponse = yield raydium_sdk_1.Liquidity.makeRemoveLiquidityInstructionSimple({
            connection: config_1.connection,
            poolKeys,
            userKeys: {
                owner: input.wallet.publicKey,
                payer: input.wallet.publicKey,
                tokenAccounts: input.walletTokenAccounts,
            },
            amountIn: input.removeLpTokenAmount,
            makeTxVersion: config_1.makeTxVersion,
        });
        return { txids: yield (0, util_1.buildAndSendTx)(removeLiquidityInstructionResponse.innerTransactions) };
    });
}
function howToUse() {
    return __awaiter(this, void 0, void 0, function* () {
        const lpToken = config_1.DEFAULT_TOKEN['RAY_USDC-LP']; // LP
        const removeLpTokenAmount = new raydium_sdk_1.TokenAmount(lpToken, 100);
        const targetPool = 'EVzLJhqMtdC1nPmz8rNd6xGfVjDPxpLZgq7XJuNfMZ6'; // RAY-USDC pool
        const walletTokenAccounts = yield (0, util_1.getWalletTokenAccount)(config_1.connection, config_1.wallet.publicKey);
        ammRemoveLiquidity({
            removeLpTokenAmount,
            targetPool,
            walletTokenAccounts,
            wallet: config_1.wallet,
        }).then(({ txids }) => {
            /** continue with txids */
            console.log('txids', txids);
        });
    });
}
//# sourceMappingURL=ammRemoveLiquidity.js.map