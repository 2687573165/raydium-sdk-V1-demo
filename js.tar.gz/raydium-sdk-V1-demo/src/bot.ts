

import bs58 from "bs58";
import { Liquidity , Market, Percent, Token, TokenAmount,CurrencyAmount,TokenAccount,SPL_ACCOUNT_LAYOUT,LiquidityPoolKeys} from "@raydium-io/raydium-sdk";
import {
  makeTxVersion,
} from '../config';
import {
  buildAndSendTx,
} from './util';
import { Connection, clusterApiUrl, Logs, Context ,PublicKey,Keypair,Transaction,Signer} from '@solana/web3.js';
import { AnchorProvider } from "@coral-xyz/anchor";
import { DecimalUtil, Percentage } from "@orca-so/common-sdk";
import {
  WhirlpoolContext, buildWhirlpoolClient, 
  PDAUtil, swapQuoteByInputToken, IGNORE_CACHE
} from "@orca-so/whirlpools-sdk";
import Decimal from "decimal.js";

const TOKEN_PROGRAM_ID = new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA')
const connection: Connection = new Connection("https://rpc.ankr.com/solana/8eeea1727223c7cfa93a7ec0f4bdeac5e009b47a365e89b759c852fec72d4180", 'confirmed');
let TokenMap: Map<string, boolean> = new Map();
TokenMap.set("So11111111111111111111111111111111111111112",true)
TokenMap.set("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v",true)

async function Swap(pool:string) {
  // Create WhirlpoolClient
  const provider = AnchorProvider.env();
  const ORCA_WHIRLPOOL_PROGRAM_ID = new PublicKey("whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc");
  const ctx = WhirlpoolContext.withProvider(provider, ORCA_WHIRLPOOL_PROGRAM_ID);
  const client = buildWhirlpoolClient(ctx);

  console.log("endpoint:", ctx.connection.rpcEndpoint);
  console.log("wallet pubkey:", ctx.wallet.publicKey.toBase58());


  const fromToken = {mint: new PublicKey("BgNSCjWzeruX7wcDxedh5Q8Z9dw8CRLJJvyZwtD2XHji"), decimals: 9};
  const toToken = {mint: new PublicKey("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"), decimals: 6};




  const whirlpool_pubkey = new PublicKey(pool)
  const whirlpool = await client.getPool(whirlpool_pubkey);
  
  const amount_in = new Decimal("50" /* devUSDC */);

  // // Obtain swap estimation (run simulation)
  const quote = await swapQuoteByInputToken(
    whirlpool,
    // Input token and amount
    fromToken.mint,
    DecimalUtil.toBN(amount_in, fromToken.decimals),
    // Acceptable slippage (10/1000 = 1%)
    Percentage.fromFraction(10, 1000),
    ctx.program.programId,
    ctx.fetcher,
    IGNORE_CACHE,
  );

  // // Output the estimation
  console.log("estimatedAmountIn:", DecimalUtil.fromBN(quote.estimatedAmountIn, fromToken.decimals).toString(), "fromToken");
  console.log("estimatedAmountOut:", DecimalUtil.fromBN(quote.estimatedAmountOut, toToken.decimals).toString(), "toToken");
  console.log("otherAmountThreshold:", DecimalUtil.fromBN(quote.otherAmountThreshold, toToken.decimals).toString(), "toToken");

  // // Send the transaction
  const tx = await whirlpool.swap(quote);
  // tx.build
  const signature = await tx.buildAndExecute();
  console.log("signature:", signature);

  // // Wait for the transaction to complete
  // const latest_blockhash = await ctx.connection.getLatestBlockhash();
  // await ctx.connection.confirmTransaction({signature, ...latest_blockhash}, "confirmed");
}

async function Block_Logs() {
  
  const Logsconnection: Connection = new Connection("https://rpc.ankr.com/solana/ws/8eeea1727223c7cfa93a7ec0f4bdeac5e009b47a365e89b759c852fec72d4180", 'confirmed');

  const programIds = [
    new PublicKey('whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc'), // orca
    new PublicKey('675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8'), // Raydium
    // 添加更多程序ID...
  ];
  const subscriptionIds =  programIds.map(programId => 
    Logsconnection.onLogs(programId, async (logs, context) => {
          for (let index = 0; index < logs.logs.length; index++) {
            const element = logs.logs[index];
            // console.log(element)
            //raydium
            if( programId.toBase58() == "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8"){
            if(element.includes("initialize2: InitializeInstruction2")){
              // console.log(`New logs for program ${programId.toBase58()}:`);
              // console.log('Block:', context.slot);
              // console.log('Logs:', logs.logs);
              console.log('Raydium  signature:', logs.signature);
              let data = await GetTransaction(logs.signature)
            }
          }
               // orca
          if( programId.toBase58() == "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc"){
            if(element == "Program log: Instruction: InitializePool"){
              // console.log(`New logs for program ${programId.toBase58()}:`);
              // console.log('Block:', context.slot);
              // console.log('Logs:', logs.logs);
              console.log('orca signature:', logs.signature);
              let data = await GetTransaction(logs.signature)
              }
            }
          }
        
  
    })
  );
}

async function GetTransaction(tx:string): Promise<void> {
    console.log(tx)
   
    // InitializePool
    connection.getTransaction(tx, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 })
      .then(transactionInfo => {
        // console.log(transactionInfo.transaction.message);
        if (transactionInfo != null){
          if ('instructions' in transactionInfo.transaction.message) {
            const getAccountKeys = transactionInfo.transaction.message.getAccountKeys()
            let accounts = transactionInfo.transaction.message.instructions
            for (let index = 0; index < accounts.length; index++) {
              const element = accounts[index];
              if(element.accounts.length == 11){
                console.log(getAccountKeys.get(element.accounts[1])?.toBase58())
                console.log(getAccountKeys.get(element.accounts[2])?.toBase58())
                console.log(getAccountKeys.get(element.accounts[4])?.toBase58())
              }
            }
            // Swap(getAccountKeys.get(accounts[0]).toBase58())
       
          } else {
      
           let staticAccountKeys = transactionInfo.transaction.message.staticAccountKeys
           let Instructions =  transactionInfo.transaction.message.compiledInstructions
              for (let index = 0; index < Instructions.length; index++) {
                const element = Instructions[index];
                if(element.accountKeyIndexes.length == 21){
                  let pool = staticAccountKeys[element.accountKeyIndexes[4]].toBase58()
                  let tokenA =  staticAccountKeys[element.accountKeyIndexes[8]].toBase58()
                  let tokenB = staticAccountKeys[element.accountKeyIndexes[9]].toBase58()
                  raydiumSwap(pool)
                  // if(TokenMap.get(tokenA)){

                  // }else if(TokenMap.get(tokenB)){

                  // }
                }
                
              }
          } 
        }

        // console.log(transactionInfo.transaction.message.compiledInstructions)
        // console.log(transactionInfo.transaction.message.addressTableLookups)

     
   
      })
      .catch(err => {
        console.error(err);
      });   
}


// Raydium_Swap

async function getTokenAccountsByOwner(
    connection: Connection,
    owner: PublicKey,
  ) {
    const tokenResp = await connection.getTokenAccountsByOwner(
      owner,
      {
        programId: TOKEN_PROGRAM_ID
      },
    );
  
    const accounts: TokenAccount[] = [];
  
    for (const { pubkey, account, } of tokenResp.value) {
      accounts.push({
        
        programId:TOKEN_PROGRAM_ID,
        pubkey,
        accountInfo:SPL_ACCOUNT_LAYOUT.decode(account.data)
      });
    }
  
    return accounts;
  }

async function get_token_amount(poolId:string, buying:boolean){

    try{
        

        const rpc_url = "https://api.mainnet-beta.solana.com";


        const version :  4 | 5 = 4


        const connection = new Connection(rpc_url); 

        const account = await connection.getAccountInfo(new PublicKey(poolId));
        const { state: LiquidityStateLayout }  = Liquidity.getLayouts(version)
      
        //@ts-ignore
        const fields = LiquidityStateLayout.decode(account?.data);

        const { status, baseMint, quoteMint, lpMint, openOrders, targetOrders, baseVault, quoteVault, marketId, baseDecimal, quoteDecimal, } = fields;
        
        var is_valid:boolean = false;

        [quoteMint,baseMint,lpMint].forEach((e)=>{
            if (e.toBase58() != '11111111111111111111111111111111'){
                is_valid = true;
            }
        })
        if (!is_valid){return -1}
        
        //fetching token data
        const secretkey = bs58.decode("hDwP6axbYSQEvSwA7V7t1LP5QJEDAq6LVffXHEaGTWNZhz7uzXqeN7pvj5RSDwnPLmhrUzg1rPeSPbnPXzuqyQb");
        const ownerKeypair = Keypair.fromSecretKey(secretkey);

        const owner_address = ownerKeypair.publicKey;

        
        const tokenAddress = buying?quoteMint:baseMint

        //console.log(tokenAddress.toBase58());

        const bal = await connection.getBalance(new PublicKey(owner_address.toBase58()));

        if (bal < 0.01){
            return -2
        }
        
        if (tokenAddress.toBase58() == 'So11111111111111111111111111111111111111112'){
            return (bal / 1000000000) - 0.0099 
        }else{

            const tokenAccounts = await connection.getParsedTokenAccountsByOwner(owner_address, { programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA')});
        
            for (var cand in tokenAccounts.value){
                if (tokenAccounts.value[cand].account.data.parsed.info.mint === tokenAddress.toBase58()){
                    const tokenAccount = tokenAccounts.value[cand];
                    const tokenBalance:number = tokenAccount.account.data.parsed.info.tokenAmount.uiAmount;
                    return tokenBalance
                }
            }
            return 0

        }

    }catch(e){
        console.log(e)
        return -1
    }

}


async function fetchPoolKeys(
    connection: Connection,
    poolId: PublicKey,
    version :  4 | 5 = 4
  ) {
  
    const serumVersion = 10
    const marketVersion:3 = 3
  
    const programId = new PublicKey('675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8');
    const serumProgramId = new PublicKey('srmqPvymJeFKQ4zGQed1GFppgkRHL9kaELCbyksJtPX')
    const account = await connection.getAccountInfo(poolId)

    const { state: LiquidityStateLayout }  = Liquidity.getLayouts(version)
  
    //@ts-ignore
    const fields = LiquidityStateLayout.decode(account?.data);
    const { status, baseMint, quoteMint, lpMint, openOrders, targetOrders, baseVault, quoteVault, marketId, baseDecimal, quoteDecimal, } = fields;
  
    let withdrawQueue, lpVault;
    if (Liquidity.isV4(fields)) {
      withdrawQueue = fields.withdrawQueue;
      lpVault = fields.lpVault;
    } else {
      withdrawQueue = PublicKey.default;
      lpVault = PublicKey.default;
    }
    
    // uninitialized
    // if (status.isZero()) {
    //   return ;
    // }
  
    const associatedPoolKeys = Liquidity.getAssociatedPoolKeys({
      version:version,
      marketVersion,
      marketId,
      baseMint: baseMint,
      quoteMint:quoteMint,
      baseDecimals: baseDecimal.toNumber(),
      quoteDecimals: quoteDecimal.toNumber(),
      programId,
      marketProgramId:serumProgramId,
    });
  
    const poolKeys = {
      id: poolId,
      baseMint,
      quoteMint,
      lpMint,
      version,
      programId,
  
      authority: associatedPoolKeys.authority,
      openOrders,
      targetOrders,
      baseVault,
      quoteVault,
      withdrawQueue,
      lpVault,
      marketVersion: serumVersion,
      marketProgramId: serumProgramId,
      marketId,
      marketAuthority: associatedPoolKeys.marketAuthority,
    };

    const marketInfo = await connection.getAccountInfo(marketId);

    const { state: MARKET_STATE_LAYOUT } = Market.getLayouts(marketVersion);
    //@ts-ignore
    const market = MARKET_STATE_LAYOUT.decode(marketInfo.data);
  
    const {
      baseVault: marketBaseVault,
      quoteVault: marketQuoteVault,
      bids: marketBids,
      asks: marketAsks,
      eventQueue: marketEventQueue,
    } = market;
  
    // const poolKeys: LiquidityPoolKeys;
    return {
      ...poolKeys,
      ...{
        marketBaseVault,
        marketQuoteVault,
        marketBids,
        marketAsks,
        marketEventQueue,
      },
    };
  }

async function compute(
    connection: Connection, poolKeys: any,
    curr_in:PublicKey , curr_out:PublicKey, 
    amount_in:number, slip:number
    ){
    try{

        const poolInfo = await Liquidity.fetchInfo({connection,poolKeys})
        console.log("开放时间:",poolInfo.startTime.toString())
        //setting up decimals
        var in_decimal:number; 
        var out_decimal:number; 

        if(curr_in.toBase58() === poolKeys.baseMint.toBase58()){
            in_decimal = poolInfo.baseDecimals
            out_decimal = poolInfo.quoteDecimals
        }else{
            out_decimal = poolInfo.baseDecimals;
            in_decimal = poolInfo.quoteDecimals;
        }
    
        //priming and computing
        const amountIn = new TokenAmount(new  Token(TOKEN_PROGRAM_ID,curr_in, in_decimal),amount_in, false);

        const currencyOut = new Token(TOKEN_PROGRAM_ID ,curr_out, out_decimal);
      
        const slippage = new Percent(slip, 100)
      
        const {
            amountOut,
            minAmountOut,
            currentPrice,
            executionPrice,
            priceImpact,
            fee,
        } = Liquidity.computeAmountOut({ poolKeys, poolInfo, amountIn, currencyOut, slippage})
        
        return [
            amountOut,
            minAmountOut,
            currentPrice,
            executionPrice,
            priceImpact,
            fee,
            amountIn,
        ]

    }catch(e){
        console.log(e);
        return 1
    }  
}

async function raydiumSwap(pool:string) {
    const secretkey = bs58.decode("hDwP6axbYSQEvSwA7V7t1LP5QJEDAq6LVffXHEaGTWNZhz7uzXqeN7pvj5RSDwnPLmhrUzg1rPeSPbnPXzuqyQb");
    const ownerKeypair = Keypair.fromSecretKey(secretkey);

    // const token_amount= await get_token_amount("HNeta6oxYy6DHT5gwEBFbxNeAj7U3wutUWzZtcjc2W17",true);
    // console.log(token_amount)


    const version :  4 | 5 = 4
    const pool_keys = await fetchPoolKeys(connection,new PublicKey(pool),4);
    const poolKeys = pool_keys as LiquidityPoolKeys
    // console.log( pool_keys)
    var token_in_key:PublicKey;
    var token_out_key:PublicKey;
    if(TokenMap.get(pool_keys.quoteMint.toBase58())){
      token_in_key = pool_keys.quoteMint;
      token_out_key = pool_keys.baseMint;
    }else{
      token_in_key = pool_keys.baseMint;
      token_out_key = pool_keys.quoteMint;
    }


    // console.log(token_in_key)
    // console.log(token_out_key)
    const computation:any = await compute(connection,pool_keys,token_in_key,token_out_key,0.00001,100)
    
    const amountOut = computation[0];

    const minAmountOut = computation[1];

    const currentPrice = computation[2];

    const executionPrice = computation[3];

    const priceImpact = computation[4];

    const fee = computation[5];

    const amountIn = computation[6];

    console.log(`\n\tAmount out: ${amountOut.toFixed()},\n\tMin Amount out: ${minAmountOut.toFixed()}`)
     const token_accounts = await getTokenAccountsByOwner(connection, ownerKeypair.publicKey);
      // -------- step 2: create instructions by SDK function --------
    const  inst  = await Liquidity.makeSwapInstructionSimple({
      connection,
      poolKeys,
      userKeys: {
        tokenAccounts: token_accounts,
        owner: ownerKeypair.publicKey,
      },
      amountIn: amountIn,
      amountOut: minAmountOut,
      fixedSide: 'in',
      makeTxVersion,
    });
    const tx = new Transaction()
    const signers:Signer[] = [ownerKeypair]

    inst.innerTransactions[0].instructions.forEach(e=>{
      tx.add(e);
    })

    inst.innerTransactions[0].signers.forEach(e=>{
      signers.push(e);
    })

   
    // 获取当前时间的时间戳（毫秒）
    const timestampInMilliseconds = Date.now();

    // 将毫秒时间戳转换为秒
    const timestampInSeconds = Math.floor(timestampInMilliseconds / 1000);

    // 打印时间戳
    console.log(timestampInSeconds);

    // const txids =  await buildAndSendTx(inst.innerTransactions) 
    sendTx(connection, tx, signers)
    // console.log(txids)
  }

async function sendTx(connection: Connection, transaction: Transaction, signers: Array<Signer>){
  
    const hash_info = (await connection.getLatestBlockhashAndContext()).value;
    
    transaction.recentBlockhash = hash_info.blockhash
    transaction.lastValidBlockHeight = hash_info.lastValidBlockHeight
    transaction.feePayer = signers[0].publicKey
  
  
    transaction.sign(...signers);
    const rawTransaction = transaction.serialize();
  
  
    var txid:string;
    try{
      txid = await connection.sendRawTransaction(rawTransaction,{skipPreflight: true,})
      console.log(txid)
    }
    catch(e){
      console.log(e)
      return 1
    }

    // while (true){
    //   const ret = await connection.getSignatureStatus(txid, {searchTransactionHistory:true})
    //   try {
    //     //@ts-ignore
    //     if (ret){
    //       if (ret.value && ret.value.err == null){
    //         return 0
    //       } else if (ret.value && ret.value.err != null){
    //         return 1
    //       }else{
    //         continue
    //       }
    //     }
    //   } catch(e){
    //     return 1
    //   }

    // }

  }

Block_Logs().catch(err => {
    console.error(err);
});
// raydiumSwap("DNdf5pgTVewhHfmqwkp8cT3aGmZdgXSyNu6EwG7cac8g")